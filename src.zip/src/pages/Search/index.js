function Search() {
    return ( <h2>Search Page</h2> );
}

export default Search;