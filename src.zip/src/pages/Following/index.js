function Following() {
    return ( <h2>Following Page</h2> );
}

export default Following;