function Profile() {
    return ( <h2>Profile Page</h2> );
}

export default Profile;